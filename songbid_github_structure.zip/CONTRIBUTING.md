# Contributing to SongBid

Thanks for your interest in SongBid!

Right now this project is in an early MVP stage. The goal is to provide a simple, web-based music studio where creators can:

- load a track (often AI-generated),
- record their own vocals,
- and eventually check melody originality and splice specific lines.

---

## How to Run

For now, everything lives in `/app`:

- Open `app/index.html` in a browser, or
- Serve the `app` folder with any simple static server.

---

## Ways to Help

- Improve the UI layout and styles
- Improve microphone recording UX
- Add simple error handling
- Propose structure for integrating future backend APIs
- Add documentation or comments

---

## Git Workflow

1. Fork the repo.
2. Create a feature branch:
   ```bash
   git checkout -b feature/short-description
   ```
3. Make your changes.
4. Commit with a clear message.
5. Open a Pull Request back to this repo.

Please keep changes focused and small where possible.
