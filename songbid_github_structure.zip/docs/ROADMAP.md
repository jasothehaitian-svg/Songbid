# SongBid Roadmap (MVP-Focused)

This is a simple, developer-facing roadmap for the SongBid web MVP.

---

## Phase 1 – Basic Studio (Now)

Goal: A stable browser app that:
- loads an audio file
- plays it
- records a mic input
- lets the user download their vocal

Tasks:
- [x] Basic HTML/CSS layout in `/app`
- [x] File input + `<audio>` player
- [x] Mic recording with `MediaRecorder`
- [ ] Simple error messages (no mic, no file, etc.)
- [ ] Light UI polish (icons, spacing, mobile tweaks)

---

## Phase 2 – UX Improvement

Goal: Make it feel like a real product, not a demo.

Tasks:
- [ ] "Suno mode" description (how to use AI tracks legally)
- [ ] Simple 3-step wizard (Load → Lyrics → Record)
- [ ] Save lyrics to localStorage
- [ ] Visual indicator while recording
- [ ] Basic help text for creators

---

## Phase 3 – Melody Guard™ & Redo Line™ (Backend engines)

Goal: Integrate backend audio DSP (later, when budget allows).

Tasks:
- [ ] Define API contract for Melody Guard:
  - POST ref + vocal → similarity JSON
- [ ] Define API contract for Redo Line:
  - POST original + segment + time → new vocal file
- [ ] Connect frontend to these APIs
- [ ] Render a simple "heatmap" or segment list (Green/Yellow/Red)

---

## Phase 4 – Accounts & Projects

Goal: Let users log in and save work.

Tasks:
- [ ] Auth (email/password or OAuth)
- [ ] Project model (track, lyrics, takes, notes)
- [ ] "My Projects" screen
- [ ] Basic backend (Node + DB)

---

This file is intentionally simple. It’s meant to guide future devs, not lock in details.
